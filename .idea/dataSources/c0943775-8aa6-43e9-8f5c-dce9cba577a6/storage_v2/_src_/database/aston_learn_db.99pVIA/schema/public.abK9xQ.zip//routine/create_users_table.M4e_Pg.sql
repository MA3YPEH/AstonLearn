create procedure create_users_table()
    language plpgsql
as
$$
BEGIN
    CREATE TABLE IF NOT EXISTS public.users (
                                                id int NOT NULL PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
                                                name VARCHAR(255) NOT NULL,
                                                email VARCHAR(255) UNIQUE,
                                                age INT,
                                                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
END;
$$;

alter procedure create_users_table() owner to postgres;

